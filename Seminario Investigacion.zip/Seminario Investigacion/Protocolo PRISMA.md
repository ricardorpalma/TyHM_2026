
Estándares y Herramientas recomendadas

Para asegurar el rigor científico, la mayoría de las disciplinas guían sus protocolos utilizando el estándar internacional **PRISMA** (Preferred Reporting Items for Systematic Reviews and Meta-Analyses). [[1](https://www.youtube.com/watch?v=hFBqpVJU5CM), [2](https://www.youtube.com/watch?v=YwVYmKrro8c&t=78)]

- **Guías metodológicas:** Puedes explorar la lista de extensiones PRISMA y otras directrices en Equator Network.
- **Registro oficial:** Para evitar la duplicidad de esfuerzos y registrar tu protocolo formalmente (especialmente en áreas de salud y ciencias sociales), puedes utilizar plataformas como PROSPERO. [[1](https://www.youtube.com/watch?v=hFBqpVJU5CM)]

Estructura clave de un protocolo

Un protocolo formal debe incluir los siguientes elementos antes de iniciar cualquier búsqueda: [[1](https://www.lluiscodina.com/revision-literatura-scoping-review/)]

- **Pregunta de investigación:** Definida idealmente mediante el formato estructurado (como PICO: Población, Intervención, Comparación y Resultados). [[1](https://jenni.ai/es/blog/systematic-literature-review-guide), [2](https://translate.google.com/translate?u=https://mtechaccess.co.uk/7-steps-systematic-literature-review/&hl=es&sl=en&tl=es&client=sge)]
- **Criterios de elegibilidad:** Reglas claras de **inclusión y exclusión** (ej. idioma, año de publicación, diseño del estudio). [[1](https://federico-toledo.com/revision-sistematica-de-la-literatura-tips-para-investigar-mejor/), [2](https://translate.google.com/translate?u=https://mtechaccess.co.uk/7-steps-systematic-literature-review/&hl=es&sl=en&tl=es&client=sge)]
- **Fuentes de información:** Las bases de datos académicas a utilizar (ej. Scopus, Web of Science, PubMed, IEEE) y otras estrategias de búsqueda (literatura gris).
- **Estrategia de búsqueda:** Las palabras clave (keywords) y los operadores booleanos (AND, OR, NOT) que se ejecutarán.
- **Selección de estudios:** El proceso por el cual se tamizarán los artículos (generalmente por título, resumen y texto completo).
- **Extracción de datos:** Los campos exactos que se recolectarán de cada artículo seleccionado (ej. autor, metodología, tamaño de muestra, conclusiones). [[1](https://federico-toledo.com/revision-sistematica-de-la-literatura-tips-para-investigar-mejor/)]
- **Evaluación de la calidad:** Las herramientas o criterios que se usarán para evaluar el riesgo de sesgo en los estudios incluidos.
- **Síntesis de los datos:** Cómo se analizarán y presentarán los resultados (ej. metaanálisis cuantitativo o síntesis narrativa)