
Para consultar la API de **OpenAlex** y extraer de forma automatizada los papers cualitativos y reportes necesarios para tu revisión sistemática PRISMA, se utiliza el método de solicitudes GET pasando los filtros estructurados por parámetros de URL. [[1](https://ropensci.github.io/openalexR/reference/oa_query.html)]

La API de OpenAlex no procesa cuerpos JSON en peticiones POST para búsquedas genéricas, sino que requiere **parámetros de consulta indexados**. El siguiente archivo JSON representa la **configuración exacta de la llamada HTTP** (un "API Request Blueprint" en formato JSON) que debés inyectar en tu script de Python, R o herramienta de automatización para traer la colección exacta de papers.

### Json Openalex


{
  "api_endpoint": "https://api.openalex.org/works",
  "request_method": "GET",
  "query_parameters": {
    "search": "(\"olive oil\" OR \"olivicultura\" OR \"olivar\") AND (\"Argentina\" OR \"Cuyo\" OR \"Mendoza\" OR \"San Juan\" OR \"La Rioja\")",
    "filter": "from_publication_date:2020-01-01,abstract.search:(\"polycrisis\" OR \"crisis\" OR \"tariff\" OR \"geopolitics\" OR \"supply chain\" OR \"artificial intelligence\" OR \"water scarcity\")",
    "sort": "relevance_score:desc",
    "per_page": 50,
    "mailto": "rpalma@uncu.edu.ar"
  },
  "documentation_note": "El parámetro 'mailto' te ubica en el 'polite pool' de OpenAlex, garantizando respuestas más rápidas y consistentes."
}


