
Para estructurar tu paper cualitativo bajo los estándares más avanzados de investigación automatizada y metodológica, ==debés fusionar el **protocolo ARA (Agent-Native Research Artifact)** —que optimiza la colaboración humano-IA en capas de abstracción [1]— con el rigor metodológico de la **Declaración PRISMA** para la revisión sistemática==.

El enfoque cualitativo se centrará en la **Teoría Fundamentada (Grounded Theory)** y el **Análisis de Contenido Cualitativo**, permitiendo codificar cómo las macro-variables (geopolítica y tecnología) impactan en los actores locales de Mendoza, San Juan y La Rioja.

---

📥 Plantilla JSON: Configuración del Flujo ARA + PRISMA

Este archivo JSON define el entorno del agente para que actúe como un nodo de investigación nativo, ejecutando el protocolo de escritura y el embudo de selección de literatura de PRISMA

### Json ARA-PRISMA

{
  "ara_protocol_config": {
    "artifact_type": "Agent-Native Research Artifact (ARA)",
    "framework_version": "ARA-1.0",
    "epistemic_mode": "Human-Agent Co-Creation",
    "execution_stages": [
      {
        "stage": 1,
        "name": "Knowledge Graph Construction",
        "action": "Estructurar las 6 variables macro (Ormuz, Trump, Venezuela, Milei, Thiel, IA) y mapear sus vectores de impacto hacia la microeconomía de Cuyo y La Rioja."
      },
      {
        "stage": 2,
        "name": "PRISMA Systematic Pipeline",
        "action": "Ejecutar las fases de Identificación, Cribado (Screening), Elegibilidad e Inclusión de literatura científica y reportes sectoriales."
      },
      {
        "stage": 3,
        "name": "Recursive Multi-Agent Drafting",
        "action": "Redactar secciones de forma aislada, ejecutando bucles de crítica y refinamiento antes de consolidar el texto final."
      }
    ]
  },
  "prisma_methodology": {
    "databases": ["Scopus", "Web of Science", "SciELO", "Google Scholar", "Reportes de la Bolsa de Comercio de Mendoza", "INTA", "CRILAR"],
    "search_string": "(‘olive oil’ OR ‘olivicultura’) AND (‘geopolitics’ OR ‘tariffs’ OR ‘artificial intelligence’ OR ‘economic policy’) AND (‘Argentina’ OR ‘Mendoza’ OR ‘San Juan’ OR ‘La Rioja’)",
    "screening_criteria": {
      "inclusion": [
        "Estudios cualitativos sobre economías regionales argentinas",
        "Análisis de cadenas globales de valor agroalimentarias",
        "Reportes geopolíticos de impacto logístico y arancelario",
        "Papers sobre adopción de AgTech e IA en agricultura de precisión"
      ],
      "exclusion": [
        "Artículos puramente técnicos de biología molecular del olivo",
        "Estudios cuantitativos sin interpretación de contexto macroeconómico",
        "Reportes comerciales previos al año 2020"
      ]
    }
  },
  "qualitative_analysis_framework": {
    "methodology": "Systematic Qualitative Literature Review + Grounded Theory Coding",
    "coding_nodes": {
      "axial_code_1": "Vulnerabilidad y resiliencia de la cadena olivícola cuyana ante shocks externos.",
      "axial_code_2": "Disrupción tecnológica (IA/AgTech) como vector de mitigación del estrés hídrico.",
      "axial_code_3": "Alineación político-ideológica nacional (Milei/Thiel) y su correlación con la atracción de capitales de riesgo."
    }
  }
}


