Para estructurar un paper académico que combine macroeconomía global, geopolítica y tecnología aplicada a la olivicultura de **Mendoza, San Juan y La Rioja**, el flujo de trabajo ideal en formato **JSON** debe actuar como un orquestador que divida los complejos temas solicitados en variables limpias.

El siguiente esquema JSON organiza tu flujo de trabajo de investigación científica, asignando contextos específicos a la IA para evitar alucinaciones y conectar las variables macro (como Peter Thiel o el Estrecho de Ormuz) con el impacto micro-regional en Cuyo y La Rioja.

[[Plantilla Oliva]]