
🔄 Flujo de Trabajo Paso a Paso (Workflow)

Para ejecutar este paper de manera "Agent-Native", debés fragmentar el proceso en prompts secuenciales utilizando los datos del JSON superior. No le pidas todo el paper a la IA; ejecutá el siguiente protocolo:

Paso 1: El Embudo PRISMA (Metodología)

Pedile a la IA que simule el diagrama de flujo PRISMA.

- **Prompt operativo:** _«Utilizando el módulo "prisma_methodology" del JSON, simula la fase de Identificación y Cribado. Genera una matriz cualitativa que clasifique 15 fuentes hipotéticas (pero realistas, ej. informes del INTA, artículos de revistas de geopolítica) y justifica la inclusión o exclusión de cada una según los criterios definidos.»_

Paso 2: Construcción del Grafo de Conocimiento (Fase 1 ARA)

Antes de escribir un párrafo, la IA debe conectar los conceptos abstractos.

- **Prompt operativo:** _«Actúa como un agente de mapeo epistémico (ARA Stage 1). Crea una tabla de relaciones cruzadas donde expliques conceptualmente cómo el pensamiento de Peter Thiel sobre monopolios premium se intersecta con las políticas de desregulación de Milei para favorecer la adopción de IA en el riego de los olivares de San Juan.»_

Paso 3: Redacción por Capas Co-Creadas (Fase 3 ARA)

Iniciá la redacción cualitativa sección por sección. Al ser un artefacto nativo de agente, el texto no debe sonar a "relleno predictivo", sino a un análisis denso y crítico.

- **Prompt operativo:** _«Redacta la sección "Disrupción Tecnológica e IA en el Centro-Oeste Argentino". Aplica el nodo de codificación cualitativa axial 2. Utiliza un estilo académico formal (APA 7). El análisis debe contrastar la crisis hídrica real de La Rioja y Mendoza con las soluciones algorítmicas predictivas, evitando generalidades.»_
- 
- [[JSON ARA PRISMA]]

