{
  "project_metadata": {
    "title": "Geopolítica, Tecnología y Olivicultura: Impacto Multidimensional en la Región de Cuyo y La Rioja (2026)",
    "target_format": "Academic Paper / Research Article",
    "geographic_scope": ["Mendoza", "San Juan", "La Rioja"]
  },
  "research_framework": {
    "system_instruction": "Actúa como un economista agrario experto en geopolítica y tecnología. Analiza variables globales y tradúcelas exclusivamente en impactos para la producción, costos y exportación del aceite de oliva del centro-oeste argentino.",
    "chapters": [
      {
        "id": 1,
        "section": "Contexto Internacional y Shock Arancelario",
        "key_variables": ["Aranceles de EE. UU. del 10% al 15% a la UE", "Acuerdo Comercial Argentina-EE. UU. 2026 (Arancel Cero)"],
        "analytical_focus": "Analizar cómo los aranceles de la administración estadounidense a Europa abren una ventana de competitividad para el aceite de oliva a granel y fraccionado de Cuyo frente a España e Italia."
      },
      {
        "id": 2,
        "section": "Logística Global y Rutas Marítimas en Crisis",
        "key_variables": ["Conflicto del Estrecho de Ormuz", "Costos de fletes marítimos", "Crisis de suministro energético"],
        "analytical_focus": "Evaluar el impacto de la inestabilidad en Ormuz sobre el precio internacional del petróleo y las rutas navieras. Explicar cómo el aumento de costos de fletes redirecciona la oferta global y cómo afecta los costos de insumos importados (fertilizantes, maquinaria) en San Juan y La Rioja."
      },
      {
        "id": 3,
        "section": "Geopolítica Regional y Desalineación Comercial",
        "key_variables": ["Escenario hipotético/crisis en Venezuela", "Alineamiento geopolítico con EE. UU."],
        "analytical_focus": "Discutir el impacto del posicionamiento argentino frente al eje bolivariano/venezolano. Evaluar el riesgo político y la reconfiguración de bloques comerciales en América Latina (Mercosur) que alteren las exportaciones de aceite hacia mercados regionales como Brasil."
      },
      {
        "id": 4,
        "section": "Política Económica Nacional (Modelo Milei)",
        "key_variables": ["Retenciones 0% a economías regionales", "Desregulación laboral", "Acceso al mercado de cambios"],
        "analytical_focus": "Estudiar la rentabilidad del sector olivícola tras la consolidación de las retenciones al 0% para el aceite de oliva. Evaluar si la baja de aranceles locales compensa la inflación en dólares de los costos de producción (energía para riego subterráneo en San Juan y La Rioja)."
      },
      {
        "id": 5,
        "section": "Filosofía Escasa y Capital de Riesgo (Peter Thiel)",
        "key_variables": ["Tesis de monopolios 'Zero to One'", "Inversión tecnológica en agro", "Capital libertario"],
        "analytical_focus": "Vincular el pensamiento de Peter Thiel (escapar de la competencia perfecta mediante la diferenciación radical) con la reconversión de la industria olivícola argentina hacia variedades premium de alta gama (AOVE de nicho) para atraer inversiones tecnológicas y Venture Capital."
      },
      {
        "id": 6,
        "section": "La Revolución de la Inteligencia Artificial en el Campo",
        "key_variables": ["Modelos predictivos climáticos", "Automatización del riego por IA", "Optimización de cosecha"],
        "analytical_focus": "Proponer casos de uso de IA aplicados a la crisis hídrica de Cuyo: sensores con algoritmos de IA para optimizar el riego por goteo, predicción de heladas tardías y clasificación automatizada de calidad de aceitunas mediante visión por computadora."
      }
    ]
  },
  "output_parameters": {
    "academic_tone": "Formal, econométrico, descriptivo",
    "citation_style": "APA 7th Edition",
    "required_data_points": ["Evolución de hectáreas plantadas en La Rioja", "Matriz energética de San Juan", "Capacidad exportadora de ProMendoza"]
  }
}
