
library(httr2)
library(tidyverse)
library(jsonlite)

# 1. Función para reconstruir el abstract invertido de OpenAlex
parse_abstract <- function(abstract_inverted_index) {
  if (is.null(abstract_inverted_index) || length(abstract_inverted_index) == 0) {
    return("")
  }
  
  # Crear un dataframe a partir de la lista indexada
  words <- names(abstract_inverted_index)
  positions <- abstract_inverted_index
  
  # Mapear cada palabra a sus posiciones respectivas
  abstract_df <- map2_df(words, positions, function(word, pos) {
    tibble(word = word, pos = as.numeric(pos))
  })
  
  # Ordenar por posición y colapsar en un solo texto plano
  abstract_clean <- abstract_df %>%
    arrange(pos) %>%
    pull(word) %>%
    paste(collapse = " ")
  
  return(abstract_clean)
}

# 2. Función principal de extracción de datos
fetch_and_export_prisma_csv <- function(output_filename = "prisma_openalex_records.csv") {
  message("🚀 Iniciando consulta en OpenAlex desde R para la poli-crisis olivícola...")
  
  endpoint <- "https://openalex.org"
  
  # Definir los parámetros base de la query
  query_params <- list(
    search = '("olive oil" OR "olivicultura" OR "olivar") AND ("Argentina" OR "Cuyo" OR "Mendoza" OR "San Juan" OR "La Rioja")',
    filter = 'from_publication_date:2020-01-01,abstract.search:("polycrisis" OR "crisis" OR "tariff" OR "geopolitics" OR "supply chain" OR "artificial intelligence" OR "water scarcity")',
    sort = "relevance_score:desc",
    per_page = "50",
    mailto = "ricardo.palma@ingenieria.uncuyo.edu.ar" # Reemplazar por tu email real
  )
  
  all_works <- list()
  page <- 1
  has_more <- TRUE
  
  # Bucle de paginación
  while (has_more) {
    query_params$page <- as.character(page)
    
    # Construir y ejecutar la request usando httr2
    req <- request(endpoint) %>% 
      req_url_query(!!!query_params)
    
    resp <- req_perform(req)
    
    if (resp_status(resp) != 200) {
      stop(paste("❌ Error en la API. Código de estado:", resp_status(resp)))
    }
    
    data <- resp_body_json(resp)
    results <- data$results
    all_works <- c(all_works, results)
    
    message(paste("📦 Página", page, ": Se descargaron", length(results), "registros."))
    
    # Control de flujo e interrupción si se llega al final
    count <- data$meta$count
    per_page <- data$meta$per_page
    
    if (page * per_page >= count || length(results) == 0) {
      has_more <- FALSE
    } else {
      page <- page + 1
      Sys.sleep(0.5) # Respeto técnico al servidor
    }
  }
  
  if (length(all_works) == 0) {
    message("⚠️ No se encontraron papers con los criterios especificados.")
    return(NULL)
  }
  
  # 3. Procesamiento y limpieza del JSON a un Tibble estructurado para PRISMA
  parsed_records <- map_df(all_works, function(work) {
    
    # Extraer autores y unirlos con punto y coma
    authors <- map_chr(work$authorships, ~ .x$author$display_name) %>% 
      paste(collapse = "; ")
    
    # Extraer revista o repositorio fuente de manera segura
    source_name <- tryCatch({
      work$primary_location$source$display_name
    }, error = function(e) "Unknown Source")
    if (is.null(source_name)) source_name <- "Unknown Source"
    
    # Limpiar el ID de la URL de OpenAlex
    clean_id <- str_split(work$id, "/")[[1]] %>% last()
    
    # Reconstruir el abstract utilizando la función del paso 1
    abstract_text <- parse_abstract(work$abstract_inverted_index)
    
    # Retornar una fila limpia
    tibble(
      ID_OpenAlex = clean_id,
      Title = ifelse(is.null(work$title), "No Title", work$title),
      Authors = authors,
      Publication_Year = ifelse(is.null(work$publication_year), NA, work$publication_year),
      Journal_or_Source = source_name,
      DOI = ifelse(is.null(work$doi), "", work$doi),
      URL = work$id,
      Abstract = abstract_text,
      PRISMA_Screening_Decision = "", # Columna en blanco para codificación
      PRISMA_Exclusion_Reason = ""    # Columna en blanco para justificaciones
    )
  })
  
  # 4. Exportar a CSV de forma nativa con readr
  write_csv(parsed_records, output_filename)
  
  message(paste("✅ ¡Proceso completado con éxito! Matriz guardada en:", output_filename))
  message(paste("📊 Total de registros listos para revisión en R:", nrow(parsed_records)))
}

# Ejecutar el script en tu consola de R o RStudio
fetch_and_export_prisma_csv()
