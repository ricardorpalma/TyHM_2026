library(tidyverse)
library(tidytext)
library(tm)
library(igraph)
library(ggraph)

analyze_olivicultura_text <- function(input_filename = "prisma_openalex_records.csv") {
  
  if (!file.exists(input_filename)) {
    stop(paste("❌ No se encuentra el archivo:", input_filename, ". Ejecutá primero el script de extracción."))
  }
  
  message("📖 Cargando y preprocesando abstracts para el análisis cualitativo...")
  
  # 1. Cargar la matriz PRISMA
  records <- read_csv(input_filename, show_col_types = FALSE) %>% 
    filter(!is.na(Abstract) & Abstract != "")
  
  # 2. Definir diccionario personalizado de stop words (palabras sin valor analítico)
  custom_stop_words <- c(
    stopwords("es"), stopwords("en"),
    "study", "analysis", "results", "paper", "research", "production", "effects",
    "estudio", "analisis", "resultados", "produccion", "efectos", "impact", "impacto"
  )
  
  # 3. Tokenización y Limpieza de Palabras Individuales
  message("🔤 Calculando las palabras más frecuentes...")
  words_cleaned <- records %>%
    select(ID_OpenAlex, Abstract) %>%
    unnest_tokens(word, Abstract) %>% 
    mutate(word = str_to_lower(word),
           word = str_remove_all(word, "[[:punct:]]")) %>% 
    filter(!word %in% custom_stop_words & !str_detect(word, "^[0-9]+$") & nchar(word) > 2)
  
  # Conteo de frecuencia simple
  top_words <- words_cleaned %>%
    count(word, sort = TRUE)
  
  print("🏆 TOP 15 Palabras Clave más frecuentes en los abstracts encontrados:")
  print(head(top_words, 15))
  
  # 4. Análisis de Co-ocurrencia (Bigramas) para conectar variables de la Poli-crisis
  message("🔗 Analizando conexiones de conceptos (Poli-crisis)...")
  
  bigrams <- records %>%
    select(ID_OpenAlex, Abstract) %>%
    unnest_tokens(bigram, Abstract, token = "ngrams", n = 2) %>%
    separate(bigram, c("word1", "word2"), sep = " ") %>%
    filter(!word1 %in% custom_stop_words,
           !word2 %in% custom_stop_words) %>%
    filter(!str_detect(word1, "^[0-9]+$"),
           !str_detect(word2, "^[0-9]+$")) %>% 
    count(word1, word2, sort = TRUE)
  
  # Filtrar conexiones significativas para graficar (ej: que aparezcan más de 2 veces)
  bigram_graph <- bigrams %>%
    filter(n >= 2) %>%
    as_tbl_graph()
  
  # 5. Generar Graficación del Mapa Conceptual de la Literatura
  message("🎨 Generando grafo de relaciones conceptuales...")
  
  network_plot <- ggraph(bigram_graph, layout = "fr") +
    geom_edge_link(aes(edge_alpha = n, edge_width = n), edge_colour = "darkolivegreen3") +
    geom_node_point(color = "darkolivegreen", size = 4) +
    geom_node_text(aes(label = name), vjust = 1.5, hjust = 0.5, repel = TRUE, size = 4.5) +
    labs(
      title = "Red de Co-ocurrencia de Términos: Poli-crisis y Olivicultura en Cuyo",
      subtitle = "Análisis cualitativo automatizado de abstracts de OpenAlex (Protocolo ARA)",
      caption = "Las líneas más gruesas indican mayor fuerza de asociación en la literatura."
    ) +
    theme_void() +
    theme(plot.title = element_text(face = "bold", size = 14, hjust = 0.5),
          plot.subtitle = element_text(size = 10, hjust = 0.5, italic = TRUE))
  
  # Guardar el gráfico en el directorio de trabajo
  ggsave("red_conceptos_olivicultura.png", plot = network_plot, width = 10, height = 7, dpi = 300)
  message("💾 Gráfico conceptual guardado con éxito como 'red_conceptos_olivicultura.png'")
  
  return(list(frecuencias = top_words, bigramas = bigrams))
}

# Ejecutar el análisis
resultados_cualitativos <- analyze_olivicultura_text()
